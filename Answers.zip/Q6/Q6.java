package Q6;

import java.util.Hashtable;
import java.util.Scanner;

public class Q6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Hashtable<Character, Integer> costs = new Hashtable<>();

        costs.put('a', 1);
        costs.put('b', 2);
        costs.put('c', 3);

        costs.put('d', 1);
        costs.put('e', 2);
        costs.put('f', 3);

        costs.put('g', 1);
        costs.put('h', 2);
        costs.put('i', 3);

        costs.put('j', 1);
        costs.put('k', 2);
        costs.put('l', 3);

        costs.put('m', 1);
        costs.put('n', 2);
        costs.put('o', 3);

        costs.put('p', 1);
        costs.put('q', 2);
        costs.put('r', 3);

        costs.put('s', 1);
        costs.put('t', 2);
        costs.put('u', 3);

        costs.put('v', 1);
        costs.put('w', 2);
        costs.put('x', 3);

        costs.put('y', 1);
        costs.put('z', 2);

        costs.put('.', 1);
        costs.put(',', 2);
        costs.put('!', 3);

        costs.put(' ', 1);

        String line = input.nextLine();

        int cost = 0;

        for (int i = 0; i < line.length(); i++)
        {
            cost += costs.get(line.charAt(i));
        }

        System.out.println(cost);
    }
}
