#include <iostream>
#include <cstdio>

using namespace std;


int main()
{


    int cand;
    int elec;

    cin >> cand >> elec;
    if(cand != 0)
    {
        if(elec != 0){
            int elecs[cand];

            for (int i = 0 ; i < cand; i++)
            {

                elecs[i] = 0;
            }

            int temp;
            for (int i = 0; i < elec; i++)
            {
                cin >> temp;
                elecs[temp - 1]++;
            }

            for (int i = 0; i < cand; i++)
            {

                printf("%.2f%s\n", (double)elecs[i] / elec * 100, "%");
            }
        }
        else{
            for (int i = 0; i < cand; i++)
            {
                cout<<"0.00%"<<endl;
            }
        }
    }
}
