package Q4;

import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

           int candidates , r;
           candidates = input.nextInt();
           r = input.nextInt();

           if (candidates != 0)
           {
               int[] count = new int[candidates];
               int temp;
               for (int i = 0; i < r; i++) {
                   temp = input.nextInt();
                   count[temp - 1]++;
               }
               if(r == 0){
                   for (int i = 0; i < candidates; i++) {
                       System.out.println("0.00%");
                       if(i == candidates - 1){
                           break;
                       }
                   }
               }
               else
               {
                   for (int i = 0; i <candidates ; i++) {
                       System.out.printf("%.2f%s\n" , (double) count[i]/r * 100 , "%");
                   }
               }
           }
        }
    }
