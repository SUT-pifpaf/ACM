package Q2;

import java.util.Arrays;
import java.util.Scanner;

public class Q2 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int numberOfWords = Integer.parseInt(input.nextLine());
        String[] words = new String[numberOfWords];
        for (int i = 0; i < numberOfWords; i++) {
            words[i] = input.nextLine();
        }
        String character = input.nextLine();
        Arrays.sort(words);
        for (int i = 0; i < numberOfWords; i++) {
            if(words[i].startsWith(character)){
                System.out.println(words[i]);
            }
        }
    }
}
