package Q7;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Q7 {
    public static void main(String[] args) throws FileNotFoundException {
        FileInputStream inputText = new FileInputStream("src\\Q7\\input.txt");
        Scanner input = new Scanner(inputText);
//        Scanner input2 = new Scanner(System.in);
    }
}
